rootProject.name = "MetadataTest"

