

package org.example;
private final static URL = "https://www.demoblaze.com/";
private  final  static VALID_USER = "ABC@ABC.COM";
private  final  static INVALID_USER = "EFG@EFG.COM";
private  final  static SIGNUPLOCATOR = "//*[@id="signin2"]";
private  final  static USERNAME = "//*[@id="sign-username"]";
private  final  static PASSWORD = "//*[@id="sign-password"]";


//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class LoginPage {

    public void signUP ()
    {
        NavigateToURL nav = new NavigateToURL();
        Actions AC = new Actions(driver);
        nav.navToURL(URL);
        WebElement signUpLink = driver.findElement(By.xpath(SIGNUPLOCATOR));
        signUpLink.click();

        WebElement getUserName = driver.findElement(By.xpath(USERNAME));
        getUserName.click();
        AC.sendKeys(VALID_USER).build().perform();

        WebElement getPassword = driver.findElement(By.xpath(PASSWORD));
        getPassword.click();
        AC.sendKeys("123456A").build().perform();

        WebElement SignUpButton = driver.findElement(By.xpath("//*[@id=\"signInModal\"]/div/div/div[3]/button[2]"));
        SignUpButton.click();

    }

}

