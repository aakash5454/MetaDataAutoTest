import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class NavigateToURL {
    public static void main(String[] args) {
        // Set the path to chromedriver executable

    }

    public void navToURL (String url) {
        System.setProperty("webdriver.chrome.driver", "path_to_chromedriver");

        // Create a new instance of ChromeDriver
        WebDriver driver = new ChromeDriver();

        // Navigate to the specified URL
        driver.get("https://www.demoblaze.com/");
    }
}